# OpenShift HAProxy Cartridge
OpenShift cartridges are documented in the [Cartridge Guide](http://openshift.github.io/documentation/oo_cartridge_guide.html).