from setuptools import setup


setup(name='APIProxy',
      version='0.1',
      description=("Proxy that enables authorised domains to make MailChimp "
                   "and OpenTok API requests without providing the API key "
                   "every time."),
      author='Artur Gaspar',
      author_email='artur.gaspar.00@gmail.com',
      install_requires=['Twisted', 'pyOpenSSL', 'service_identity', 'txmongo'])
