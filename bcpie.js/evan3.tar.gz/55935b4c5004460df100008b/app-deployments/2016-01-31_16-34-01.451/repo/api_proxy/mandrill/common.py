MANDRILL_API_HOST = b"mandrillapp.com"
