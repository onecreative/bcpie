import json
from cgi import parse_header
from urllib import urlencode
from urlparse import parse_qsl

from twisted.internet import reactor
from twisted.internet.defer import inlineCallbacks
from twisted.internet.ssl import optionsForClientTLS
from twisted.web import http
from twisted.web.resource import ErrorPage

from ..proxy import BaseAPIProxyResource
from ..util import headers_as_dict
from .common import MANDRILL_API_HOST


class MandrillProxyResource(BaseAPIProxyResource):
    @inlineCallbacks
    def do_proxy(self, request, uri):
        creds = yield self.get_credentials_for_request_or_render_error(request,
                                                                       uri)
        if creds is None:
            return

        request.content.seek(0, 0)
        body = request.content.read()

        may_ignore_body = request.method in {'GET', 'HEAD', 'OPTIONS'}

        ctype = request.requestHeaders.getRawHeaders(b'content-type')
        if not ctype and not may_ignore_body:
            request.render(ErrorPage(
                http.UNSUPPORTED_MEDIA_TYPE,
                http.responses[http.UNSUPPORTED_MEDIA_TYPE],
                "A Content-Type is required."
            ))
            return

        try:
            ctype = ctype[0]
            ctype, options = parse_header(ctype)
            if ctype == "application/json":
                data = json.loads(body)
                reencode = json.dumps
            elif ctype == "application/x-www-form-urlencoded":
                data = parse_qsl(body, keep_blank_values=True,
                                 strict_parsing=True)
                reencode = urlencode
            else:
                request.render(ErrorPage(
                    http.UNSUPPORTED_MEDIA_TYPE,
                    http.responses[http.UNSUPPORTED_MEDIA_TYPE],
                    "Content-Type {} is not supported.".format(ctype)
                ))
                return

            data['key'] = creds['api_key']
            body = reencode(data)

        except (IndexError, TypeError, ValueError):
            if not may_ignore_body:
                request.render(ErrorPage(http.BAD_REQUEST,
                                         http.responses[http.BAD_REQUEST],
                                         ("Failed to parse content as {}."
                                          ).format(ctype)))
                return

        host = MANDRILL_API_HOST

        headers = request.requestHeaders
        headers.removeHeader("Referer")
        headers.setRawHeaders("Host", [host])
        headers.setRawHeaders("Content-Length", [bytes(len(body))])
        headers = headers_as_dict(headers)

        reactor.connectSSL(host, 443,
                           self.proxyclient_factory_cls(request.method,
                                                        uri,
                                                        request.clientproto,
                                                        headers,
                                                        body,
                                                        request),
                           optionsForClientTLS(hostname=host.decode('idna')))
