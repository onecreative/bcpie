import json
from urlparse import urlunparse

from ..auth_setup import BaseAuthChecker
from ..util import StringBodyProducer
from .common import MANDRILL_API_HOST


class MandrillAuthChecker(BaseAuthChecker):
    def _method(self, auth_info):
        return 'POST'

    def _url(self, auth_info):
        return urlunparse(('https', MANDRILL_API_HOST,
                           '/api/1.0/users/ping.json', '', '', ''))

    def _body_producer(self, auth_info):
        return StringBodyProducer(json.dumps({'key': auth_info['key']}))

    def _auth_info_to_store(self, auth_info):
        d = super(MandrillAuthChecker, self)._auth_info_to_store(auth_info)
        d['api_key'] = auth_info['key']
        return d
