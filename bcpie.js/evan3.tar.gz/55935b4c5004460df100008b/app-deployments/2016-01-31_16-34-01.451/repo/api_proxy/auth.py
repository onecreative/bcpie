import re
from urlparse import urlparse

from twisted.internet.defer import inlineCallbacks, returnValue
from twisted.web import http
from twisted.web.resource import ErrorPage, ForbiddenResource, Resource

from . import settings
from .mongodb import api_keys_collection
from .util import get_base_url


class AuthenticatedResource(Resource, object):
    def __init__(self, api_name):
        super(AuthenticatedResource, self).__init__()
        self.api_name = api_name

    @inlineCallbacks
    def get_all_credentials_for_site(self, referer):
        referer_base_url = get_base_url(referer)
        doc = yield api_keys_collection.find_one({'domain': referer_base_url})
        if doc is not None and self.api_name in doc:
            returnValue(doc)
        else:
            returnValue(None)

    @inlineCallbacks
    def get_credentials_for_request_or_render_error(self, request, uri):
        referer = request.getHeader("Referer")
        if referer is None:
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     "Missing Referer header."))
            return

        try:
            creds = yield self.get_all_credentials_for_site(referer)
        except ValueError:
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     "Invalid Referer header."))
            return

        if creds is None:
            request.render(ForbiddenResource())
            return

        if not (creds['is_admin'] or self.is_allowed(uri, request.method)):
            request.render(ForbiddenResource(("{} API call {} {} not allowed."
                                              ).format(self.api_name,
                                                       request.method, uri)))
            return

        returnValue(creds[self.api_name])

    def is_allowed(self, uri, method):
        path = urlparse(uri)[2]

        for rule in settings.FORBIDDEN_API_CALLS.get(self.api_name, []):
            pattern = rule.get('pattern', "")
            if re.match(pattern, path):
                try:
                    if method.upper() in rule['methods']:
                        return False
                except KeyError:
                    return False

        return True
