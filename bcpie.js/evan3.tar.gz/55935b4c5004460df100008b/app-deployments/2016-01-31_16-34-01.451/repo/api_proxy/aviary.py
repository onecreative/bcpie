import hashlib
import json
import time
import uuid

from twisted.internet.defer import inlineCallbacks
from twisted.web.resource import Resource
from twisted.web.server import NOT_DONE_YET

from . import settings
from .auth import AuthenticatedResource
from .auth_setup import BaseAuthChecker
from .util import errback_for_request, set_access_control_headers


class AviaryResource(Resource, object):
    def __init__(self):
        super(AviaryResource, self).__init__()
        self.putChild("getAuth", AviaryAuthenticationResource('aviary'))


class AviaryAuthenticationResource(AuthenticatedResource):
    hash_method = 'sha1'

    def render(self, request):
        set_access_control_headers(request)
        return super(AviaryAuthenticationResource, self).render(request)

    def render_OPTIONS(self, request):
        request.setResponseCode(204)
        request.finish()
        return NOT_DONE_YET

    def render_GET(self, request):
        r = self.do_render_GET(request)
        r.addErrback(errback_for_request(request))
        return NOT_DONE_YET

    @inlineCallbacks
    def do_render_GET(self, request):
        creds = yield self.get_credentials_for_request_or_render_error(request,
                                                                       None)
        if creds is None:
            return

        body = json.dumps(self.make_aviary_auth())

        request.setResponseCode(200)
        request.setHeader("Content-Type", "application/json")
        request.setHeader("Content-Length", str(len(body)))
        request.write(body)
        request.finish()

    def is_allowed(self, uri, method):
        return True

    def make_aviary_auth(self):
        api_key = settings.AVIARY_API_KEY
        api_secret = settings.AVIARY_API_SECRET

        timestamp = str(int(time.time()))
        salt = str(uuid.uuid4())

        h = hashlib.new(self.hash_method)
        h.update(api_key + api_secret + timestamp + salt)
        signature = h.hexdigest()

        return {
            "apiKey": api_key,
            "salt": salt,
            "timestamp": timestamp,
            "encryptionMethod": self.hash_method,
            "signature": signature
        }


class AviaryAuthChecker(BaseAuthChecker):
    needs_auth_info = False

    def check_auth(self, auth_info):
        return {}
