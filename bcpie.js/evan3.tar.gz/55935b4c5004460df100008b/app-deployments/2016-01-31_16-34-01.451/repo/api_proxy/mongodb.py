from txmongo.connection import ConnectionPool

from . import settings


# It is needed to specify database name in URI because of a bug in txmongo.
connection = ConnectionPool(settings.MONGODB_URI + settings.MONGODB_DB_NAME)
db = connection[settings.MONGODB_DB_NAME]
api_keys_collection = db[settings.MONGODB_API_KEYS_COLLECTION]
