import json
import os
import sys


try:
    BIND_IP = os.environ['OPENSHIFT_PYTHON_IP']
except KeyError:
    pass

try:
    BIND_PORT = int(os.environ['OPENSHIFT_PYTHON_PORT'])
except KeyError:
    pass


try:
    MONGODB_URI = os.environ['OPENSHIFT_MONGODB_DB_URL']
except KeyError:
    pass

MONGODB_DB_NAME = "evan3"
MONGODB_API_KEYS_COLLECTION = "api_keys"


with open(os.path.join(os.path.dirname(sys.modules[__package__].__file__),
                       'forbidden_api_calls.json')) as f:
    FORBIDDEN_API_CALLS = json.load(f)


AVIARY_API_KEY = "df6402eaf46c41a9859fe7fa7b63b35d"
AVIARY_API_SECRET = "1507adb7-964d-4933-bcbd-af844c22660d"


try:
    from local_settings import *
except ImportError:
    pass
