from urllib import quote
from urlparse import urlparse

from twisted.internet.defer import Deferred
from twisted.web.proxy import ProxyClient, ProxyClientFactory
from twisted.web.server import NOT_DONE_YET

from .auth import AuthenticatedResource
from .util import errback_for_request, set_access_control_headers


class AccessControlAwareProxyClient(ProxyClient, object):
    def handleHeader(self, key, value):
        if not key.lower().startswith("access-control-allow-"):
            super(AccessControlAwareProxyClient, self).handleHeader(key, value)


class AccessControlAwareProxyClientFactory(ProxyClientFactory):
    protocol = AccessControlAwareProxyClient


class BaseAPIProxyResource(AuthenticatedResource):
    proxyclient_factory_cls = AccessControlAwareProxyClientFactory

    isLeaf = True

    def render(self, request):
        set_access_control_headers(request)

        if request.method == 'OPTIONS':
            return self.render_OPTIONS(request)

        uri = '/'.join(map(quote, request.postpath))
        if not uri.startswith('/'):
            uri = '/' + uri

        qs = urlparse(request.uri)[4]
        if qs:
            uri += '?' + qs

        r = self.do_proxy(request, uri)
        if isinstance(r, Deferred):
            r.addErrback(errback_for_request(request))
            return NOT_DONE_YET
        else:
            return r

    def render_OPTIONS(self, request):
        request.setResponseCode(204)
        request.finish()
        return NOT_DONE_YET
