from functools import partial
from urlparse import urlparse, urlunparse

from twisted.internet.defer import succeed
from twisted.python import log
from twisted.web import http
from twisted.web.iweb import IBodyProducer
from twisted.web.resource import ErrorPage
from zope.interface import implementer


def deferred_request_error_handler(request, failure):
    log.err(failure)

    if not request.startedWriting:
        status_code = http.INTERNAL_SERVER_ERROR
        request.render(ErrorPage(status_code,
                                 http.RESPONSES[status_code],
                                 "An error has occurred."))

    if not request.finished:
        request.finish()


errback_for_request = partial(partial, deferred_request_error_handler)


def set_access_control_headers(request):
    request.setHeader("Access-Control-Allow-Origin", "*")
    request.setHeader("Access-Control-Allow-Credentials", "true")

    allow_headers = request.getHeader("Access-Control-Request-Headers")
    if allow_headers is not None:
        request.setHeader("Access-Control-Allow-Headers", allow_headers)

    allow_method = request.getHeader("Access-Control-Request-Method")
    if allow_method is not None:
        request.setHeader("Access-Control-Allow-Methods", allow_method)


def get_base_url(url):
    url = urlparse(url)
    base_url = urlunparse((url[0], url[1], '', '', '', ''))
    base_url = base_url.rstrip("/")
    return base_url


def headers_as_dict(headers):
    d = {}
    for header, values in headers.getAllRawHeaders():
        d[header] = ", ".join(values)
    return d


@implementer(IBodyProducer)
class StringBodyProducer(object):
    def __init__(self, body):
        self.body = body
        self.length = len(body)

    def startProducing(self, consumer):
        consumer.write(self.body)
        return succeed(None)

    def pauseProducing(self):
        pass

    def resumeProducing(self):
        pass

    def stopProducing(self):
        pass
