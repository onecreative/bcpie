import json
from collections import Mapping
from urlparse import urlparse

import opentok
from twisted.internet import reactor
from twisted.internet.defer import inlineCallbacks
from twisted.internet.ssl import optionsForClientTLS
from twisted.web import http
from twisted.web.resource import ErrorPage

from ..proxy import BaseAPIProxyResource
from ..util import headers_as_dict
from .common import OPENTOK_API_HOST


class OpenTokProxyResource(BaseAPIProxyResource):
    @inlineCallbacks
    def do_proxy(self, request, uri):
        creds = yield self.get_credentials_for_request_or_render_error(request,
                                                                       uri)
        if creds is None:
            return

        request.content.seek(0, 0)

        path = urlparse(uri)[2]
        if path == "/session/token/create":
            self.generate_token(request, creds)
            return

        host = OPENTOK_API_HOST

        headers = request.requestHeaders
        headers.removeHeader("Referer")
        headers.setRawHeaders("Host", [host])
        headers.setRawHeaders("X-TB-PARTNER-AUTH",
                              ["{api_key}:{api_secret}".format(**creds)])
        headers = headers_as_dict(headers)

        reactor.connectSSL(host, 443,
                           self.proxyclient_factory_cls(request.method,
                                                        uri,
                                                        request.clientproto,
                                                        headers,
                                                        request.content.read(),
                                                        request),
                           optionsForClientTLS(hostname=host.decode('idna')))

    def generate_token(self, request, creds):
        try:
            data = json.load(request.content)
        except ValueError as err:
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     err.message))
            return

        if not isinstance(data, Mapping):
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     "A JSON object is required."))
            return

        try:
            session_id = data['sessionId']
        except KeyError:
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     "Missing session ID."))
            return

        args = {}
        try:
            args['expire_time'] = data['expireTime']
        except KeyError:
            pass
        try:
            args['role'] = opentok.Roles[data['role']]
        except KeyError:
            pass
        try:
            args['data'] = data['data']
        except KeyError:
            pass

        try:
            opentok_ = opentok.OpenTok(creds['api_key'], creds['api_secret'])
            token = opentok_.generate_token(session_id, **args)
        except opentok.OpenTokException as err:
            request.render(
                ErrorPage(http.INTERNAL_SERVER_ERROR,
                          http.responses[http.INTERNAL_SERVER_ERROR],
                          err.message)
            )
        else:
            request.setResponseCode(200)
            request.setHeader("Content-Type", "text/plain")
            request.write(token.encode('ascii'))
            request.finish()
