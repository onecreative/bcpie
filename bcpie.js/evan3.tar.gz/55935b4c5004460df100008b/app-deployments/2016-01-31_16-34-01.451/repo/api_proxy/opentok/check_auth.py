from urlparse import urlunparse

from ..auth_setup import BaseAuthChecker
from .common import OPENTOK_API_HOST


class OpenTokAuthChecker(BaseAuthChecker):
    def _url(self, auth_info):
        return urlunparse(('https', OPENTOK_API_HOST,
                           "/v2/partner/[{}]/archive".format(auth_info['key']),
                           '', 'offset=0&count=1', ''))

    def _headers(self, auth_info):
        d = super(OpenTokAuthChecker, self)._headers(auth_info)
        opentok_key = auth_info['key'].encode('ascii')
        opentok_secret = auth_info['secret'].encode('ascii')
        d["X-TB-PARTNER-AUTH"] = [opentok_key + b":" + opentok_secret]
        return d

    def _auth_info_to_store(self, auth_info):
        d = super(OpenTokAuthChecker, self)._auth_info_to_store(auth_info)
        d['api_key'] = auth_info['key']
        d['api_secret'] = auth_info['secret']
        return d
