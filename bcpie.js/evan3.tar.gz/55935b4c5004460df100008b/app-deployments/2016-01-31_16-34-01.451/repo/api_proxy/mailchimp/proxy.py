from twisted.internet import reactor
from twisted.internet.defer import inlineCallbacks
from twisted.internet.ssl import optionsForClientTLS

from ..proxy import BaseAPIProxyResource
from ..util import headers_as_dict
from .common import mailchimp_domain_from_key


class MailChimpProxyResource(BaseAPIProxyResource):
    @inlineCallbacks
    def do_proxy(self, request, uri):
        creds = yield self.get_credentials_for_request_or_render_error(request,
                                                                       uri)
        if creds is None:
            return

        host = mailchimp_domain_from_key(creds['api_key'])

        headers = request.requestHeaders
        headers.removeHeader("Referer")
        headers.setRawHeaders("Host", [host])
        headers.setRawHeaders("Authorization",
                              ["apikey {api_key}".format(**creds)])
        headers = headers_as_dict(headers)

        request.content.seek(0, 0)

        reactor.connectSSL(host, 443,
                           self.proxyclient_factory_cls(request.method,
                                                        uri,
                                                        request.clientproto,
                                                        headers,
                                                        request.content.read(),
                                                        request),
                           optionsForClientTLS(hostname=host.decode('idna')))
