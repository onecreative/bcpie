MAILCHIMP_BASE_DOMAIN = ".api.mailchimp.com"


def mailchimp_domain_from_key(api_key):
    mailchimp_prefix = api_key.rsplit('-', 1)[-1]
    return (mailchimp_prefix + MAILCHIMP_BASE_DOMAIN).encode('idna')
