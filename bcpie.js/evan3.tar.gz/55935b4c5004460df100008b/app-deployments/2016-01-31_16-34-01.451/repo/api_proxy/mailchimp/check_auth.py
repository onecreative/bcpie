from urlparse import urlunparse

from ..auth_setup import BaseAuthChecker
from .common import mailchimp_domain_from_key


class MailChimpAuthChecker(BaseAuthChecker):
    test_api_call = "/3.0/authorized-apps"

    def _url(self, auth_info):
        return urlunparse(('https',
                           mailchimp_domain_from_key(auth_info['key']),
                           self.test_api_call, '', '', ''))

    def _headers(self, auth_info):
        d = super(MailChimpAuthChecker, self)._headers(auth_info)
        d["Authorization"] = ["apikey " + auth_info['key'].encode('ascii')]
        return d

    def _auth_info_to_store(self, auth_info):
        d = super(MailChimpAuthChecker, self)._auth_info_to_store(auth_info)
        d['api_key'] = auth_info['key']
        return d
