from .check_auth import MailChimpAuthChecker as AuthChecker
from .proxy import MailChimpProxyResource as ProxyResource
