import sys

from twisted.internet import reactor
from twisted.python import log
from twisted.web.resource import NoResource, Resource
from twisted.web.server import Site

from . import settings
from .util import set_access_control_headers
from .auth_setup import AuthSetupResource

from . import aviary, mailchimp, mandrill, opentok


class OkResource(Resource):
    def render_GET(self, request):
        return "Hi!"


class RootResource(Resource):
    def getChild(self, path, request):
        set_access_control_headers(request)
        return NoResource("Unknown API {}.".format(path))


root = RootResource()
# haproxy uses the root URL to check whether the application is working, and
# considers Not Found as an error.
root.putChild('', OkResource())

setup_resource = AuthSetupResource()
root.putChild('setup', setup_resource)

for name, proxy_module in {'mailchimp': mailchimp,
                           'mandrill': mandrill,
                           'opentok': opentok}.items():
    root.putChild(name, proxy_module.ProxyResource(name))
    setup_resource.auth_checkers[name] = proxy_module.AuthChecker()

root.putChild('aviary', aviary.AviaryResource())
setup_resource.auth_checkers['aviary'] = aviary.AviaryAuthChecker()


site = Site(root)


def main():
    log.startLogging(sys.stderr)
    reactor.listenTCP(settings.BIND_PORT, site, interface=settings.BIND_IP)
    reactor.run()
