import json
import re
from operator import itemgetter
from urllib import quote
from urlparse import urljoin, urlparse, urlunparse

from twisted.internet import reactor
from twisted.internet.defer import (DeferredList, inlineCallbacks,
                                    maybeDeferred, returnValue)
from twisted.web import http
from twisted.web.client import Agent, RedirectAgent, readBody
from twisted.web.http_headers import Headers
from twisted.web.resource import ErrorPage, ForbiddenResource, Resource
from twisted.web.server import NOT_DONE_YET

from .mongodb import api_keys_collection
from .util import errback_for_request, get_base_url, set_access_control_headers


class AuthSetupError(Exception):
    def __init__(self, response_status, response_body):
        super(AuthSetupError, self).__init__()
        self.response_status = response_status
        self.response_body = response_body


class AuthSetupResource(Resource, object):
    def __init__(self, auth_checkers={}):
        super(AuthSetupResource, self).__init__()
        self.agent = RedirectAgent(Agent(reactor))
        self.auth_checkers = auth_checkers or {}

    def render_OPTIONS(self, request):
        request.setResponseCode(204)
        set_access_control_headers(request)
        request.finish()
        return NOT_DONE_YET

    def render_POST(self, request):
        set_access_control_headers(request)
        d = self.actual_render_POST(request)
        d.addErrback(errback_for_request(request))
        return NOT_DONE_YET

    app_url_pattern = re.compile(r'^https://bcpie-evan-[0-9]+-apps'
                                 r'\.worldsecuresystems\.com$')

    @staticmethod
    def _add_optional_www(urls):
        for url in urls:
            yield url
            url = list(urlparse(url))
            if url[1].startswith('www.'):
                url[1] = url[1][len('www.'):]
            else:
                url[1] = 'www.' + url[1]
            yield urlunparse(tuple(url))

    @inlineCallbacks
    def actual_render_POST(self, request):
        referer = request.getHeader("Referer")
        if referer is None:
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     "Missing Referer header."))
            return

        app_base_url = get_base_url(referer)

        if not self.app_url_pattern.match(app_base_url):
            request.render(ForbiddenResource())
            return

        request.content.seek(0, 0)
        try:
            data = json.load(request.content)
        except ValueError:
            request.render(ErrorPage(http.BAD_REQUEST,
                                     http.responses[http.BAD_REQUEST],
                                     "Invalid JSON in message body."))
            return

        bc_data = data['bc']

        url = urljoin(app_base_url.encode("idna"),
                      b'/api/v2/admin/sites/' + quote(str(bc_data['site_id'])))

        response = yield self.agent.request(
            'GET',
            url,
            Headers({"Accept": ["application/json"],
                     "Authorization": [bc_data['token'].encode('ascii')]})
        )
        body = yield readBody(response)

        if not 200 <= response.code < 300:
            if response.code in {http.UNAUTHORIZED, http.FORBIDDEN}:
                code = response.code
                details = "Business Catalyst API call authorization error."
            else:
                code = http.BAD_GATEWAY
                details = ("Business Catalyst API failed with status {}."
                           ).format(response.code)

            request.render(ErrorPage(code, http.RESPONSES[code], details))
            return

        try:
            data_from_bc = json.loads(body)
        except ValueError:
            request.render(ErrorPage(http.BAD_GATEWAY,
                                     http.responses[http.BAD_GATEWAY],
                                     ("Invalid JSON response from Business "
                                      "Catalyst.")))
            return

        referer_base_urls = map(get_base_url, map(itemgetter('uri'),
                                                  data_from_bc['siteLinks']))
        referer_base_urls = self._add_optional_www(referer_base_urls)

        apis = []
        results = []
        for api, auth_checker in self.auth_checkers.items():
            try:
                api_data = data[api]
            except KeyError:
                if auth_checker.needs_auth_info:
                    continue
                else:
                    api_data = None
            apis.append(api)
            results.append(maybeDeferred(auth_checker.check_auth,
                                         api_data))

        results = yield DeferredList(results, consumeErrors=True)

        errors = []
        api_keys = {}
        for api, (ok, result) in zip(apis, results):
            if not ok:
                if result.check(AuthSetupError):
                    errors.append(("{} API call failed with status {}"
                                   ).format(api, result.value.response_status))
                else:
                    errors.append(("{} API call failed with an unknown error"
                                   ).format(api))
            else:
                api_keys[api] = result

        if api_keys:
            to_set = api_keys.copy()
            to_set['is_admin'] = True
            yield api_keys_collection.update({'domain': app_base_url},
                                             {'$set': to_set},
                                             upsert=True,
                                             safe=True)

            to_set = api_keys.copy()
            to_set['is_admin'] = False
            for referer_base_url in referer_base_urls:
                yield api_keys_collection.update({'domain': referer_base_url},
                                                 {'$set': to_set},
                                                 upsert=True,
                                                 safe=True)

        if errors:
            errors.append("")
            request.render(ErrorPage(http.BAD_GATEWAY,
                                     http.responses[http.BAD_GATEWAY],
                                     '<br />'.join(errors)))
        else:
            request.setResponseCode(204)
            request.finish()


class BaseAuthChecker(object):
    needs_auth_info = True

    def __init__(self):
        super(BaseAuthChecker, self).__init__()
        self.agent = RedirectAgent(Agent(reactor))

    def _method(self, auth_info):
        return 'GET'

    def _url(self, auth_info):
        raise NotImplementedError()

    def _headers(self, auth_info):
        return {}

    def _body_producer(self, auth_info):
        return None

    def _auth_info_to_store(self, auth_info):
        return {}

    @inlineCallbacks
    def check_auth(self, auth_info):
        response = yield self.agent.request(
            self._method(auth_info),
            self._url(auth_info),
            Headers(self._headers(auth_info)),
            self._body_producer(auth_info)
        )
        body_d = readBody(response)

        if 200 <= response.code < 300:
            returnValue(self._auth_info_to_store(auth_info))
        else:
            body = yield body_d
            raise AuthSetupError(response.code, body)
